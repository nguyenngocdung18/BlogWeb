<?php
$host = 'localhost';
$user ='root';
$pass = 'Dungpro@123';
$db_name = 'blogweb';
$connect = mysqli_connect($host, $user, $pass, $db_name);
mysqli_set_charset($connect,'utf8');

?>