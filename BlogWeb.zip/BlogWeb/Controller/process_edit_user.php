<?php

if(empty($_POST['user_id'])) {
    header('location:../index.php?error= Phải truyền mã để sửa');
    exit;
}   

$user_id =$_POST['user_id'];
if(empty($_POST['username'])||empty($_POST['password'])||empty($_POST['email'])) {
    header("location:edit_post.php?user_id=$user_id&error= Phải truyền đủ thông tin");
    exit;
}
$level = $_POST['level'];
$username =$_POST['username'];
$password =$_POST['password'];
$email =$_POST['email'];

require_once('../connect.php');

$truy_van = "UPDATE users
SET
level = '$level',
username ='$username',
password ='$password',
email ='$email'
WHERE
user_id = '$user_id' ";
mysqli_query($connect,$truy_van);
$error = mysqli_error($connect);
mysqli_close($connect);
if(empty($error)) {
    header('location:../web/manage_user.php?success=Sửa thành công');
} else{
    header("location:./edit_user.php?user_id=$user_id&error=Lỗi truy vấn");
}
