<?php
$user_id = $_GET['user_id'];

require_once '../connect.php';

$truy_van = "DELETE from users WHERE user_id =$user_id";

mysqli_query($connect,$truy_van);
mysqli_close($connect);
header('location:../web/manage_user.php?success=Xóa thành công');
?>