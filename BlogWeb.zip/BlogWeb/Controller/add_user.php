<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
<style>
#post-container{
  height: 400px;
}
.card-description {
    position: relative;
    text-align: center;
}
</style>
    <title>Add User</title>
</head>
<body>

<?php
include("../web/header_admin.php");
include("../menu.php");
?>
<main>
<form method="post" action="process_add_user.php">
<h2 class="page-heading">Add User</h2>
<div id="post-container">
    <section id="blogpost">
        <div class="card">
            <div class="card-description">
                <div>
                    Level
                    <select name="level" >
                        <option value="0">0</option>
                        <option value="1">1</option>
                    </select>
                </div>
                <div class = "input-user">
                    Username
                    <br>
                    <input type="text" name='username'>
                </div>
                <div class = "input-password">
                    Password
                    <br>
                    <input type="password" name='password'>
                </div>
                <div class = "input-email">
                    Email
                    <br>
                    <input type="email" name='email'>
                </div>
                <div>
                    <h3>        </h3>
                </div>
            </div>
    <button class = "btn-readmore"  type = "Submit" >Add User</button>
        </div>
    </section>
    <aside id="sidebar">
    <h3 align ="center">Lucky Button</h3>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="#" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
  </aside>
</div>
</div>
</form>
<?php include('../footer.php')?>
</main>
<script src="../assets/js/main.js"></script>
</body>
</html>