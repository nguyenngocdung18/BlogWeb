<?php
$level = $_POST ['level'];

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];

require '../connect.php';
$sql = "select count(*) from users
where email ='$email'";
$result =mysqli_query($connect, $sql);
$number_rows =mysqli_fetch_array($result)['count(*)'];

if($number_rows == 1){
    header('location:./add_user.php?error=Trùng email rồi!');
    exit;
}
$sql = "INSERT INTO users (level,username,password,email)
values ('$level','$username','$password','$email')";

mysqli_query($connect, $sql);

header('location: ../web/manage_user.php?success=Thêm người dùng thành công!');