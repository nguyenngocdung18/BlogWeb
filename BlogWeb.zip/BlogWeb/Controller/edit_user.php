<?php
session_start();
if(empty($_SESSION['user_id'])) {
    header('location:./login.php?error=Hãy đăng nhập');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
#post-container{
  height: 400px;
}
.card-description {
    position: relative;
    text-align: center;
}
</style>
    <title>Edit Post</title>
</head>
<body>
    <?php
        include("../web/header_admin.php");
        $user_id = $_GET['user_id'];
        require_once('../connect.php');
        include('../menu.php');

        $sql = "SELECT * FROM users WHERE user_id = $user_id";
        $result = mysqli_query($connect, $sql);
        $user = mysqli_fetch_array($result);

    ?>
<main>
<form method="post" action="process_edit_user.php">
<h2 class="page-heading">Add Post</h2>
<div id="post-container">
  <section id="blogpost">
    <div class="card">
      <div class="card-description">
        <div >
        <input type="hidden" name="user_id" value ="<?php echo $user_id ?>" >
            Level <span>                    </span>
            <select name="level" value =<?php echo $user['level']?>>
                <option value="0">0</option>
                <option value="1">1</option>
            </select>

        </div>
        <div>
        Username <br>
    <input type="text" name="username" value= "<?php echo $user['username'] ?>">
        </div>
        <div>
        Password <br>
    <input type="text" name="password" value= "<?php echo $user['password'] ?>">
        </div>
        <div>
        Email <br>
    <input type="email" name="email" value= "<?php echo $user['email'] ?>">
        </div>
        <div>
            <h3>   </h3>
        </div>
      </div>
      <button class = "btn-readmore" type = "Submit">Edit User</button>
    </div>

  </section>

  <aside id="sidebar">
    <h3 align ="center">Lucky Button</h3>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="#" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
  </aside>
</div>
</form>

<?php include('../footer.php')?>
<?php mysqli_close($connect)?>
</main>
    <script src="../assets/js/main.js"></script>
</body>
</html>