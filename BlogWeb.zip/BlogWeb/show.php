<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Document</title>
</head>
<body>
    <?php
        include './header.php';
        $post_id =$_GET['post_id'];
        require_once('connect.php');

        $sql = "SELECT * from posts where post_id = $post_id";
        $result = mysqli_query($connect, $sql);
        $tin_tuc = mysqli_fetch_array($result);

        $sql_author ="SELECT users.username AS author_name 
        FROM posts 
        INNER JOIN users ON posts.user_id = users.user_id 
        WHERE posts.post_id = $post_id";;
        $result_author = mysqli_query($connect, $sql_author);
        $author = mysqli_fetch_array($result_author);

    ?>
    <div id="searchbox">
        <form >
        <input type="search" name = "search" value="<?php echo $search?>">
        </form>
    </div>
    <main>
    <h2 class="page-heading"><?php echo $tin_tuc['tieu_de']?></h2>
    <div id="post-container">
      <section id="blogpost">
        <div class="card">
          <div class="card-meta-blogpost">
            Posted by <?php echo $author['author_name']?>
          </div>
          <div class="card-image">
            <img src="<?php echo $tin_tuc['anh']?>" height="400px" alt="Card Image">
          </div>
          <div class="card-description">
            <p><?php echo nl2br($tin_tuc['noi_dung'])?></p>
          </div>
        </div>

        <div id="comments-section">
        </div>
      </section>

      <aside id="sidebar">
        <h3>Sidebar Heading</h3>
        <p>Sidebar 1</p>
      </aside>
    </div>

    <?php mysqli_close($connect)?>
    <?php include './footer.php' ?>
</main>
<script src="/assets/js/main.js"></script>
</body>
</html>