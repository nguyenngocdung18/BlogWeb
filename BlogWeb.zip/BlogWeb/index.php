<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Dũng Blog</title>
</head>
<body>
    <?php
        include './header.php';
        require_once('connect.php');
        include("./menu.php");

        $page = 1;
        if(isset($_GET['page'])) {
            $page = $_GET['page'];
        }

        $search = '';
        if(isset($_GET['search'])) {
            $search = $_GET['search'];
        }

        $sql_so_tin_tuc = "SELECT count(*) from posts 
        WHERE tieu_de like '%$search%'";
        $mang_so_tin_tuc = mysqli_query($connect,$sql_so_tin_tuc);
        $ket_qua_so_tin_tuc = mysqli_fetch_array($mang_so_tin_tuc);
        $so_tin_tuc = $ket_qua_so_tin_tuc['count(*)'];
    
        $so_tin_tuc_tren_mot_trang = 4;
        $so_trang = ceil($so_tin_tuc/$so_tin_tuc_tren_mot_trang);
        $bo_qua = $so_tin_tuc_tren_mot_trang * ($page-1);


        $sql = "SELECT * FROM posts 
        WHERE tieu_de like '%$search%' 
        limit $so_tin_tuc_tren_mot_trang offset $bo_qua"  ;
        $result = mysqli_query($connect, $sql);
        ?>

    <div id="searchbox">
        <form >
        <input type="search" name = "search" value="<?php echo $search?>">
        </form>
    </div>
    <div id="banner">
        <h1>&lt;Dũng Blog/&gt;</h1>
        <h3>Welcome To My Website</h3>
    </div>
    <main>
        <a href="blogslist.html">
            <h2 class="section-heading">All Blogs</h2>
        </a>
        <section>
        <?php $count = 0; ?>
        <?php foreach ($result as $each){ ?>
           <?php if($count % 2 == 0 ) {?>

            <div class="card">
                <div class="card-image">
                <div class="image-container">
                    <a href="show.php?post_id=<?php echo $each['post_id']?>">
                        <img src="<?php echo $each['anh']?>" alt="Card Image">
                    </a>
                </div>
                </div>

                <div class="card-description">
                    <a href="show.php?post_id=<?php echo $each['post_id']?>">
                        <h3><?php echo $each['tieu_de']?></h3>
                    </a>
                    <p>
                    <?php
                        $lines = explode("\n", $each['noi_dung']);
                        $first_two_lines = array_slice($lines, 0, 2);
                        $first_two_lines_content = implode("\n", $first_two_lines);
                        echo nl2br($first_two_lines_content);
                    ?>
                    </p>
                    <a href="show.php?post_id=<?php echo $each['post_id']?>" class="btn-readmore">Read more</a>
                </div>
            </div>
        
        <?php $count++;?>
        <?php } else { ?>
            <div class="card">
                
                <div class="card-image">
                <div class="image-container">
                    <a href="show.php?post_id=<?php echo $each['post_id']?>">
                        <img src="<?php echo $each['anh']?>" alt="Card Image">
                    </a>
                 </div>
                </div>

                <div class="card-description">
                    <a href="show.php?post_id=<?php echo $each['post_id']?>">
                        <h3><?php echo $each['tieu_de']?></h3>
                    </a>
                    <p>
                    <?php
                        $lines = explode("\n", $each['noi_dung']);
                        $first_two_lines = array_slice($lines, 0, 2);
                        $first_two_lines_content = implode("\n", $first_two_lines);
                        echo nl2br($first_two_lines_content);
                    ?>
                    </p>
                    <a href="show.php?post_id=<?php echo $each['post_id']?>" class="btn-readmore">Read more</a>
                </div>
            </div>
        <?php $count++;?>
        <?php }?>
        <?php }?>
    </section>
    <div class="pagination">
        <?php for ($i=1; $i <= $so_trang ; $i++) { ?>
        <a href="?page=<?php echo $i?>&search=<?php echo $search?>">
            <?php echo $i?>
        </a>
    <?php }?>
    </div>
    <?php mysqli_close($connect)?>
        <h2 class="section-heading">Are you pleased? </h2>

        <section id="section-source">
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class="btn-readmore" target="_blank">
                Don't press
            </a>
        </section>
    <?php include './footer.php'?>

    </main>

    <script src="assets/js/main.js"></script>
</body>
</html>