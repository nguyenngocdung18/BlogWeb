<div>
    <br>
<?php 
    if(isset($_GET['error'])){
?>      
<b>  
    <span style ='color:red'>
        <?php echo $_GET['error']?>
    </span>
</b> 
<?php 
    }
?>
</div>
<div>
<?php 
    if(isset($_GET['success'])){
?>     
<b>  
    <span style ='color:yellow'>
        <?php echo $_GET['success']?>
    </span>
</b>
<?php 
    }
?>
</div>