<?php
session_start();
if(empty($_SESSION['user_id'])) {
    header('location:./login.php?error=Hãy đăng nhập');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style> 
    .card-description textarea {
        width: 100%;
        height: 200px; 
    }
    .card-description .input-header input {
        width: 100%;
        height:30px;
    }
    .card-description .input-img input {
        width: 100%;
        height:30px;
    }
</style>
    <title>Add Post</title>
</head>
<body>

    <?php
    include("../web/header_user.php");
    include("../menu.php");
    require_once('../connect.php');

    $post_id = $_GET['post_id'];

    $sql = "SELECT * FROM posts WHERE post_id = $post_id";
    $result = mysqli_query($connect, $sql);
    $tin_tuc = mysqli_fetch_array($result);

    ?>
<main>
<form method="post" action="process_edit.php">
<h2 class="page-heading">Add Post</h2>
<div id="post-container">
  <section id="blogpost">
    <div class="card">
      <div class="card-description">
        <div class = "input-header">
        <input type="hidden" name="post_id" value ="<?php echo $post_id ?>" >
            Header
            <input type="text" name="tieu_de" value= "<?php echo $tin_tuc['tieu_de'] ?>">

        </div>
        <div>
            Content
            <textarea name="noi_dung" ><?php echo $tin_tuc['noi_dung']?></textarea>
        </div>
        <div class = "input-img">
            Image Source
            <input type="text" name="anh" value= "<?php echo $tin_tuc['anh']?>">
        </div>
      </div>
      <button class = "btn-readmore" type = "Submit">Edit Post</button>
    </div>

  </section>

  <aside id="sidebar">
    <h3 align ="center">Lucky Button</h3>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="#" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
  </aside>
</div>
</form>

<?php include('../footer.php')?>
<?php mysqli_close($connect)?>
</main>
    <script src="../assets/js/main.js"></script>
</body>
</html>

