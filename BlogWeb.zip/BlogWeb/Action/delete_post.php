<?php
$post_id = $_GET['post_id'];

require_once '../connect.php';

$truy_van = "DELETE from posts WHERE post_id =$post_id";

mysqli_query($connect,$truy_van);
mysqli_close($connect);
header('location:../web/manage_post.php?success=Xóa thành công');
?>