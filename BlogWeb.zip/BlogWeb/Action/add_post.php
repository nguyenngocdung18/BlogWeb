<?php
session_start();
if(empty($_SESSION['user_id'])) {
    header('location:./login.php?error=Hãy đăng nhập');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style> 
    .card-description textarea {
        width: 100%;
        height: 200px; 
    }
    .card-description .input-header input {
        width: 100%;
        height:30px;
    }
    .card-description .input-img input {
        width: 100%;
        height:30px;
    }
</style>
    <title>Add Post</title>
</head>
<body>

<?php
include("../web/header_user.php");
include("../menu.php");
?>
<main>
<form method="post" action="process_add.php">
<h2 class="page-heading">Add Post</h2>
<div id="post-container">
    <section id="blogpost">
        <div class="card">
            <div class="card-description">
                <div class = "input-header">
                    <input type="hidden" name="user_id" value ="<?php echo $_SESSION['user_id']?>">
                    Tiêu đề
                    <input type="text" name="tieu_de">
                </div>
                <div>
                    Nội dung
                    <textarea name="noi_dung" cols="30" rows="10"></textarea>
                </div>
                <div class = "input-img">
                    Link ảnh
                    <input type="text" name="anh">
                </div>
            </div>
                    <button class = "btn-readmore" type = "Submit">Add Post</button>
        </div>

    </section>

    <aside id="sidebar">
    <h3 align ="center">Lucky Button</h3>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="#" class = "btn-readmore">Press</a>
    </p>
    <p>
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class = "btn-readmore">Press</a>
    </p>
  </aside>
</div>
</form>

<?php include('../footer.php')?>
</main>
    <script src="../assets/js/main.js"></script>
</body>
</html>