<?php

if(empty($_POST['post_id'])) {
    header('location:../index.php?error= Phải truyền mã để sửa');
    exit;
}   

$post_id =$_POST['post_id'];
if(empty($_POST['tieu_de'])||empty($_POST['noi_dung'])||empty($_POST['anh'])) {
    header("location:edit_post.php?post_id=$post_id&error= Phải truyền đủ thông tin");
    exit;
}

$tieu_de =$_POST['tieu_de'];
$noi_dung =$_POST['noi_dung'];
$anh =$_POST['anh'];

require_once('../connect.php');

$truy_van = "UPDATE posts 
SET
tieu_de ='$tieu_de',
noi_dung ='$noi_dung',
anh ='$anh'
WHERE
post_id = '$post_id' ";
mysqli_query($connect,$truy_van);
$error = mysqli_error($connect);
mysqli_close($connect);
if(empty($error)) {
    header('location:../web/manage_post.php?success=Sửa thành công');
} else{
    header("location:edit_post.php?post_id=$post_id&error=Lỗi truy vấn");
}
