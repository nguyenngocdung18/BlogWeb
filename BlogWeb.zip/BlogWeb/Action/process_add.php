<?php

if(empty($_POST['tieu_de'])||empty($_POST['noi_dung'])||empty($_POST['anh'])) {
    header("location:add_post.php?error= Phải truyền đủ thông tin");
}
$user_id = $_POST['user_id'];
$tieu_de = $_POST['tieu_de'];
$noi_dung = $_POST['noi_dung'];
$anh = $_POST['anh'];

require_once '../connect.php';


$sql = "INSERT INTO posts(user_id,tieu_de,noi_dung,anh) values('$user_id','$tieu_de','$noi_dung','$anh')";
mysqli_query($connect,$sql);

$error = mysqli_error($connect);
mysqli_close($connect);
if(empty($error)) {
    header('location:../web/manage_post.php?success= Thêm thành công');
} else{
    header("location:add_post.php?error=Lỗi truy vấn");
}
?>