<?php
session_start();
if(empty($_SESSION['user_id'])) {
    header('location:./login.php?error=Hãy đăng nhập');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Dũng Blog</title>
</head>
<body>
<div id="slideout-menu">
                <ul>
                    <li>
                        <a href="user.php">Home</a>
                    </li>
                    <li>
                        <a href="manage_post.php">Manage My Posts</a>
                    </li>
                    <li>
                        <a href="logout.php">Logout</a>
                    </li>
                    <li>
                        <a href="./about.php">About</a>
                    </li>
                    <li>
                        <input type="text" placeholder="Search Here">
                    </li>
                </ul>
            </div>

        </div>
    <nav>
        <div id="logo-img">
            <a href="#">
                <img src="assets/img/logo.jpg" alt="Dũng Blog Logo">
            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="/BlogWeb/web/user.php">Home</a>
            </li>
            <li>
                <a href="../Action/add_post.php?">Add Post</a>
            </li>
            <li>
                <a href="logout.php">Logout</a>
            </li>
            <li>
                <div id="search-icon">
                    <i class="fas fa-search"></i>
                </div>
            </li>
        </ul>
    </nav>
    <?php
        require_once('../connect.php');

        $user_id = $_SESSION['user_id'];

        $page = 1;
        if(isset($_GET['page'])) {
            $page = $_GET['page'];
        }

        $search = '';
        if(isset($_GET['search'])) {
            $search = $_GET['search'];
        }

        $sql_so_tin_tuc = "SELECT count(*) from posts 
        WHERE tieu_de like '%$search%'";
        $mang_so_tin_tuc = mysqli_query($connect,$sql_so_tin_tuc);
        $ket_qua_so_tin_tuc = mysqli_fetch_array($mang_so_tin_tuc);
        $so_tin_tuc = $ket_qua_so_tin_tuc['count(*)'];
    
        $so_tin_tuc_tren_mot_trang = 4;
        $so_trang = ceil($so_tin_tuc/$so_tin_tuc_tren_mot_trang);
        $bo_qua = $so_tin_tuc_tren_mot_trang * ($page-1);


        $sql = "SELECT * FROM posts 
        INNER JOIN users ON posts.user_id = users.user_id
        WHERE tieu_de like '%$search%' and posts.user_id = $user_id
        limit $so_tin_tuc_tren_mot_trang offset $bo_qua"  ;
        $result = mysqli_query($connect, $sql);
        ?>
    <div id="searchbox">
        <form >
        <input type="search" name = "search" value="<?php echo $search?>">
        </form>
    </div>
    <div id="banner">
        <h1>&lt;Dũng Blog/&gt;</h1>
        <h3>Welcome To My Website</h3>
    </div>
    <main>
        <a href="#">
            <h2 class="section-heading">My Blogs</h2>
        </a>
        <table border ="1" width ="100%">
        <tr>
            <th>Mã</th>
            <th>Tiêu đề</th>
            <th>Ảnh</th>
            <th>Sửa</th>
            <th>Xóa</th>
        </tr>
    
        <?php foreach ($result as $each){ ?>
            <tr>
                <td align ="center"><?php echo $each['post_id']?></td>
                <td>
                    <a href="../show.php?post_id=<?php echo $each['post_id']?>">
                        <?php echo $each['tieu_de']?>
                    </a>
                </td>
                <td> 
                    <img src="<?php echo $each['anh']?>" height="100">
                </td>
                <td  align ="center">
                    <a href="../Action/edit_post.php?post_id=<?php echo $each['post_id']?>".>Sửa</a>
                </td>
                <td  align ="center">
                    <a href="../Action/delete_post.php?post_id=<?php echo $each['post_id']?>">Xóa</a>
                </td>
            </tr>
        <?php }?>
    </table>
    <div class="pagination">
        <?php for ($i=1; $i <= $so_trang ; $i++) { ?>
        <a href="?page=<?php echo $i?>&search=<?php echo $search?>">
            <?php echo $i?>
        </a>
    <?php }?>
    </div>
    <?php 
    mysqli_close($connect);
    include("../menu.php");
    ?>

        <h2 class="section-heading">Are you pleased? </h2>

        <section id="section-source">
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class="btn-readmore" target="_blank">
                Don't press
            </a>
        </section>
    
    <?php        
    include '../footer.php';
    ?>

    </main>

    <script src="../assets/js/main.js"></script>
</body>
</html>