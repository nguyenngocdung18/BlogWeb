<?php
session_start();
if(empty($_SESSION['user_id'])) {
    header('location:./login.php?error=Hãy đăng nhập');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
        crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Dũng Blog</title>
</head>
<body>
<nav>
        <div id="logo-img">
            <a href="#">
                <img src="assets/img/logo.jpg" alt="Dũng Blog Logo">
            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="/BlogWeb/web/admin.php">Home</a>
            </li>
            <li>
                <a href="../Controller/add_user.php?">Add User</a>
            </li>
            <li>
                <a href="logout.php">Logout</a>
            </li>
            <li>
                <div id="search-icon">
                    <i class="fas fa-search"></i>
                </div>
            </li>
        </ul>
    </nav>
    <?php
    require_once('../connect.php');

    $page = 1;
    if(isset($_GET['page'])) {
        $page = $_GET['page'];
    }

    $search = '';
    if(isset($_GET['search'])) {
        $search = $_GET['search'];
    }

    $sql_so_user = "SELECT count(*) AS count from users 
    WHERE username like '%$search%'";
    $mang_so_user = mysqli_query($connect,$sql_so_user);
    $ket_qua_so_user = mysqli_fetch_array($mang_so_user);
    $so_user = $ket_qua_so_user['count'];
   
    $so_user_tren_mot_trang = 10;
    $so_trang = ceil($so_user/$so_user_tren_mot_trang);
    $bo_qua = $so_user_tren_mot_trang * ($page-1);


    $sql = "SELECT * FROM users
    WHERE username like '%$search%' 
    limit $so_user_tren_mot_trang offset $bo_qua"  ;
    $result = mysqli_query($connect, $sql);
    ?>
    <div id="banner">
        <h1>&lt;Dũng Blog/&gt;</h1>
        <h3>Welcome To My Website</h3>
    </div>
    <main>
    <a href="#">
            <h2 class="section-heading">All Users</h2>
        </a>
    <table border ="1" width ="100%">
        <tr>
            <th>UserID</th>
            <th>Level</th>
            <th>Username</th>
            <th>Password</th>
            <th>Email</th>
            <th>Sửa</th>
            <th>Xóa</th>
        </tr>
    
        <?php foreach ($result as $each){ ?>
            <tr>
                <td>
                        <?php echo $each['user_id']?>
                </td>
                <td> 
                    <?php echo $each['level']?>
                </td>
                <td> 
                    <?php echo $each['username']?>
                </td>
                <td> 
                    <?php echo $each['password']?>
                </td>
                <td> 
                    <?php echo $each['email']?>
                </td>
                <td>
                    <a href="../Controller/edit_user.php?user_id=<?php echo $each['user_id']?>".>Sửa</a>
                </td>
                <td>
                    <a href="../Controller/delete_user.php?user_id=<?php echo $each['user_id']?>">Xóa</a>
                </td>
            </tr>
        <?php }?>
    </table>
    <div class="pagination">
    <?php for ($i=1; $i <= $so_trang ; $i++) { ?>
        <a href="?page=<?php echo $i?>&search=<?php echo $search?>">
            <?php echo $i?>
        </a>
    <?php }?>
    </div>
    <?php mysqli_close($connect);
    include("../menu.php");
    ?>

        <h2 class="section-heading">Are you pleased? </h2>

        <section id="section-source">
            <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class="btn-readmore" target="_blank">
                Don't press
            </a>
        </section>
    
    <?php        
    include '../footer.php';
    ?>

    </main>

    <script src="../assets/js/main.js"></script>
</body>
</html>