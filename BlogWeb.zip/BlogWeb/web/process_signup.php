<?php
$username = $_POST['username'];
$level = $_POST['level'];
$email = $_POST['email'];
$password = $_POST['password'];

require '../connect.php';
$sql = "select count(*) from users
where email ='$email'";

$result =mysqli_query($connect, $sql);
$number_rows =mysqli_fetch_array($result)['count(*)'];

if($number_rows == 1){
    header('location:signup.php?error=Trùng email rồi!');
    exit;
}
$sql = "INSERT INTO users (level,username,password,email)
values ('$level','$username','$password','$email')";
mysqli_query($connect, $sql);

$sql = "select user_id from users where email = '$email'";
$result = mysqli_query($connect, $sql);
$user_id = mysqli_fetch_array($result)['user_id'];
session_start();
$_SESSION['user_id'] = $user_id;
$_SESSION['username'] = $username;

mysqli_close($connect);

header('location:./login.php?success=Tạo tài khoản thành công');