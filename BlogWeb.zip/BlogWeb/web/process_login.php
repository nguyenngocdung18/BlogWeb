<?php
$username = $_POST["username"];
$password = $_POST["password"];
require '../connect.php';
$sql = "select * from users
where username ='$username'and password ='$password'";

$result =mysqli_query($connect, $sql);
$number_rows =mysqli_num_rows($result);

if($number_rows == 1){
    session_start();
    $data = mysqli_fetch_array($result);
    $_SESSION['user_id'] = $data['user_id'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['level'] = $data['level'];
    if($_SESSION['level'] == 0){
        header('location:./user.php');
    } elseif ($_SESSION['level'] == 1) {
        header('location:./admin.php');
    } else {
        header('location:../index.php');
    }
    exit;
} 

header('location: ./login.php?error=Tên đăng nhập hoặc mật khẩu không đúng');
