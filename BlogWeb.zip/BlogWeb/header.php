<div id="slideout-menu">
                <ul>
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="web/login.php">Login</a>
                    </li>
                    <li>
                        <a href="web/signup.php">Signup</a>
                    </li>
                    <li>
                        <a href="./about.php">About</a>
                    </li>
                    <li>
                        <input type="text" placeholder="Search Here">
                    </li>
                </ul>
            </div>

        </div>
    <nav>
        <div id="logo-img">
            <a href="#">
                <img src="assets/img/logo.jpg" alt="Dũng Blog Logo">
            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="index.php">Home</a>
            </li>
            <li>
                <a href="web/login.php">Login</a>
            </li>
            <li>
                <a href="web/signup.php">Signup</a>
            </li>
            <li>
                <a href="./info.php">About</a>
            </li>
            <li>
                <div id="search-icon">
                    <i class="fas fa-search"></i>
                </div>
            </li>
        </ul>
    </nav>